# Sistema de Mantenimiento Aire Acondicionado

Usuario inicial: admin
Contrase�a: admin123 (c�mbiala despu�s)

Funciones:
- Gesti�n completa de equipos
- Cronograma con alertas
- Reportes y actualizaci�n autom�tica de fechas
- C�digos QR imprimibles
- Fotos de equipos
- Alertas por email diarias
- Exportar a Excel y PDF

�Listo para usar!